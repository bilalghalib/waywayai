'use strict'

console.log("Successfully started...");
console.log("Enjoy your drawing!");

// Initialise application
Board.init('board');
Pen.init(Board.ctx);

FloatingButton.init();
FloatingButton.onClick = Board.clearMemory.bind(Board);
Pointer.onEmpty = _.debounce(Board.storeMemory.bind(Board), 1500);
var allPoints = new Array();

// Attach event listener
var pointerDown = function pointerDown(e) {
  // Initialise pointer
  var pointer = new Pointer(e.pointerId);
  pointer.set(Board.getPointerPos(e));

  // Get function type
  Pen.setFuncType(e);
  if (Pen.funcType === Pen.funcTypes.menu) Board.clearMemory();
  else drawOnCanvas(e, pointer, Pen, true);
}
var pointerMove = function pointerMove(e) {
  if (Pen.funcType && (Pen.funcType.indexOf(Pen.funcTypes.draw) !== -1)) {

    var pointer = Pointer.get(e.pointerId);
    drawOnCanvas(e, pointer, Pen);
  }
}
var pointerCancel = function pointerLeave(e) {
  Pointer.destruct(e.pointerId);
}

Board.dom.addEventListener('pointerdown', pointerDown);
Board.dom.addEventListener('pointermove', pointerMove);
Board.dom.addEventListener('pointerup', pointerCancel);
Board.dom.addEventListener('pointerleave', pointerCancel);


// Draw method
let prevX = 0, prevY = 0;

function getWidthFromPressure(pressure) {
  let p = pressure * 1000;
  if(p < 25) return 6.75;
  if(p < 50) return 6.5;
  if(p < 100) return 6.5;
  if(p < 150) return 6.25;
  if(p < 200) return 6;
  if(p < 250) return 5.75;
  if(p < 300) return 5.5;
  if(p < 350) return 5.25;
  if(p < 400) return 5;
  if(p < 450) return 4.75;
  if(p < 500) return 4.5;
  if(p < 550) return 4.25;
  if(p < 600) return 4;
  if(p < 650) return 3.75;
  if(p < 700) return 3.5;
  if(p < 750) return 3.25;
  if(p < 800) return 3;
  if(p < 850) return 2.75;
  if(p < 900) return 2.5;
  if(p < 950) return 2.25;
  if(p < 1000) return 2;
  return 2;
}
function playOnCanvas(point) {
  let _x = point.ev.clientX + point.ev.offsetX;
  let _y = point.ev.clientY + point.ev.offsetY;

  if(prevX == 0 && prevY == 0) {
    prevX = _x;
    prevY = _y;
    return;
  }
  Board.ctx.lineWidth = getWidthFromPressure(point.ev.pressure) - 1;
  console.log(Board.ctx.lineWidth);
  Board.ctx.beginPath();
  Board.ctx.moveTo(prevX, prevY);
  Board.ctx.lineTo(_x, _y);
  Board.ctx.stroke();

  prevX = _x, prevY = _y;
}

function drawOnCanvas(e, pointerObj, Pen, mousedown) {
  var timeStampInMs = window.performance && window.performance.now && window.performance.timing && window.performance.timing.navigationStart ? window.performance.now() + window.performance.timing.navigationStart : Date.now();
  if (pointerObj) {
    pointerObj.set(Board.getPointerPos(e));
    Pen.setPen(Board.ctx, e);

    if (pointerObj.pos0.x < 0) {
      pointerObj.pos0.x = pointerObj.pos1.x - 1;
      pointerObj.pos0.y = pointerObj.pos1.y - 1;
    }


    Board.ctx.beginPath();
    Board.ctx.moveTo(pointerObj.pos0.x, pointerObj.pos0.y)
    Board.ctx.lineTo(pointerObj.pos1.x, pointerObj.pos1.y);
    Board.ctx.closePath();
    Board.ctx.stroke();
    
    allPoints.push({ev});

    pointerObj.pos0.x = pointerObj.pos1.x;
    pointerObj.pos0.y = pointerObj.pos1.y;

  }
}
