'use strict'

console.log("Successfully started...");
console.log("Enjoy your drawing!");

// Initialise application
Board.init('board');
Pen.init(Board.ctx);

FloatingButton.init();
FloatingButton.onClick = Board.clearMemory.bind(Board);
Pointer.onEmpty = _.debounce(Board.storeMemory.bind(Board), 1500);
var allPoints = new Array();

// Attach event listener
var pointerDown = function pointerDown(e) {
  // Initialise pointer
  var pointer = new Pointer(e.pointerId);
  pointer.set(Board.getPointerPos(e));

  // Get function type
  Pen.setFuncType(e);
  if (Pen.funcType === Pen.funcTypes.menu) Board.clearMemory();
  else drawOnCanvas(e, pointer, Pen, true);
}
var pointerMove = function pointerMove(e) {
  if (Pen.funcType && (Pen.funcType.indexOf(Pen.funcTypes.draw) !== -1)) {

    var pointer = Pointer.get(e.pointerId);
    drawOnCanvas(e, pointer, Pen);
  }
}
var pointerCancel = function pointerLeave(e) {
  Pointer.destruct(e.pointerId);
}

Board.dom.addEventListener('pointerdown', pointerDown);
Board.dom.addEventListener('pointermove', pointerMove);
Board.dom.addEventListener('pointerup', pointerCancel);
Board.dom.addEventListener('pointerleave', pointerCancel);


// Draw method
let prevX = 0, prevY = 0;

function getWidthFromPressure(pressure) {
let p = pressure * 1000;
return 8 - 0.25 * (p / 50);
}

let up = false;
function playOnCanvas(point) {
  //console.log(point);
  if(point == "up" || point == "down") {
    if(point == "up") {
      console.log("UP")
      up = true;
    }
    return;
  }


  let _x = point.ev.clientX + point.ev.offsetX;
  let _y = point.ev.clientY + point.ev.offsetY;

  if(up == true) {
    prevX = _x, prevY = _y;
    up = false;
    return;
  }

  if(prevX == 0 && prevY == 0) {
    prevX = _x;
    prevY = _y;
    return;
  }
  Board.ctx.lineWidth = getWidthFromPressure(point.ev.pressure) - 1;
  Board.ctx.beginPath();
  Board.ctx.moveTo(prevX, prevY);
  Board.ctx.lineTo(_x, _y);
  Board.ctx.stroke();

  prevX = _x, prevY = _y;
}

function drawOnCanvas(e, pointerObj, Pen, mousedown) {
  var timeStampInMs = window.performance && window.performance.now && window.performance.timing && window.performance.timing.navigationStart ? window.performance.now() + window.performance.timing.navigationStart : Date.now();
  if (pointerObj) {
    pointerObj.set(Board.getPointerPos(e));
    Pen.setPen(Board.ctx, e);

    if (pointerObj.pos0.x < 0) {
      pointerObj.pos0.x = pointerObj.pos1.x - 1;
      pointerObj.pos0.y = pointerObj.pos1.y - 1;
    }


    Board.ctx.beginPath();
    Board.ctx.moveTo(pointerObj.pos0.x, pointerObj.pos0.y)
    Board.ctx.lineTo(pointerObj.pos1.x, pointerObj.pos1.y);
    Board.ctx.closePath();
    Board.ctx.stroke();

    allPoints.push({ev});

    pointerObj.pos0.x = pointerObj.pos1.x;
    pointerObj.pos0.y = pointerObj.pos1.y;

  }
}
